package clicker.game

// Objects to use as event handlers n whatever

case object Click
case class BuyEquipment(id: String)
case object Update
case class GameState(a: String)
