package clicker.server

import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import clicker.game.GameActor
import com.corundumstudio.socketio.{AckRequest, SocketIOClient}
import com.corundumstudio.socketio.listener._
import clicker.game._

class StartGameListener(Server: ClickerServer) extends DataListener[String] {

     override def onData(Client: SocketIOClient, Name: String, ackSender: AckRequest): Unit = {
          val Game = Server.context.system.actorOf(Props(classOf[GameActor], Name, Server.configuration ))
          Server.ClientMap += Client -> Game
          Client.sendEvent("initialize", Server.configuration)
     }

}

class ClickListener(Server: ClickerServer) extends DataListener[Nothing] {

     override def onData(Client: SocketIOClient, Data: Nothing, ackSender: AckRequest): Unit = {
          // TODO: Send Click event
          val CurrentGame: ActorRef = Server.ClientMap(Client)
          CurrentGame ! Click
     }

}

class BuyListener(Server: ClickerServer) extends DataListener[String] {

     override def onData(Client: SocketIOClient, Data: String, ackSender: AckRequest): Unit = {
          // TODO: Send buy event
          val CurrentGame: ActorRef = Server.ClientMap(Client)
          CurrentGame ! BuyEquipment(Data)
     }

}
